import SwiftUI

struct yourtableView: View {

@State var selectedSide: SideOfTheForce = .day1
    @State var MessageInput = ""
    @State var activityList: [Event] = []
//    init(activityList: [Event]) {
//        self.activityList = activityList
//    }
    
var body: some View {
    NavigationView{
        
        VStack{
            
            ScrollView (.vertical, showsIndicators: false) {
                
                VStack{
                    Picker("Choose assdfgh", selection: $selectedSide){
                        ForEach(SideOfTheForce.allCases , id: \.self){
                            Text($0.rawValue)
                        }
                        
                    }.pickerStyle(SegmentedPickerStyle())
                       // .font(Font.custom("DIN Condensed", size: 8))
                        .background(.white)
                        .overlay(
                                   RoundedRectangle(cornerRadius: 8)
                                       .stroke(Color.white, lineWidth:5)
                               )
                        .padding()

                 //   allViews(selectedSide: selectedSide)
                    EventsListView(activityList: activityList)
                }
                
                
            } .navigationTitle("Jeddah")
                
                .navigationBarTitleDisplayMode(.inline)
            
            
            
        }
    }
    
}}
    struct yourtableView_Previews: PreviewProvider {
        static var previews: some View {
            yourtableView()
}
}
enum SideOfTheForce: String, CaseIterable{
case day1 = "day1"
case day2 = "day2"
case day3 = "day3"
}

//struct allViews: View {
//var selectedSide: SideOfTheForce
//var body: some View{
//switch selectedSide {
//case .day1:
//firstday()
//case .day2:
//secondday()
//case .day3:
//thirdday()
//}
//}
//}

struct Activity {
let id = UUID()
let name: String
let image: String
let location: String
}

struct EventsListView: View {
    @State var activityList: [Event]
    init(activityList: [Event]) {
        self.activityList = activityList
    }
    
    //func createDummyData() -> [Activity] {
    //let cornicheJeddah = Activity(name: "corniche jeddah", image: "", location: "")
    //let x = Activity(name: "x", image: "", location: "")
    //let y = Activity(name: "y", image: "", location: "")
    //let array = [cornicheJeddah, x, y]
    //return array
    
    
    @State var isshownhome=false
    
    var body: some View{
        List (activityList, id: \.day) { event in
            createCard(event: event)
        }
        
        
    }
    func createCard (event: Event) -> some View {
        return ZStack{
            VStack (spacing: 30) {
                Button {
                    
                    isshownhome.toggle()
                } label : {
                    VStack{
                        
                        Button {
                            isshownhome.toggle()
                            
                        } label:{
                            Image("2") .resizable().shadow(radius: 4).cornerRadius(10)
                            
                        }
                        
                        VStack(alignment: .leading) {
                            
                            Text(event.event)
                                .font(Font.custom("SF Pro", size: 28))
                                .foregroundColor(Color.black)
                                .padding(.top, 5)
                                .padding(.bottom, -1)
                            
                            HStack(alignment:.center){
                                Image(systemName: "mappin")
                                    .resizable()
                                    .frame(width: 9, height: 22)
                                    .foregroundColor(Color("ourcolor"))
                                Text("Loction")
                                    .font(Font.headline.weight(.bold))
                                    .font(Font.custom("SF Pro", size: 25))
                                    .foregroundColor(Color("ourcolor"))
                            }.padding(.trailing , 230)
                            
                        }
                        
                    }
                    .frame(width: 350, height: 230)
                    .background(Color.white).cornerRadius(32).overlay(
                        RoundedRectangle(cornerRadius: 32).stroke(Color("ourcolor"), lineWidth: 1))
                }
            }
        }
    }
    
}
