//
//  interstsSc3.swift
//  rahaf
//
//  Created by Rahaf Alhejaili on 25/08/1444 AH.
//

import SwiftUI

struct interstsSc3: View {
    struct purbleColor{
        
        static let ourPurble = Color("Purble")
        
        
    }
    
    @State private var isClicked = false
    @State private var isClicked1 = false
    @State private var isClicked2 = false
    @State private var isClicked3 = false
    @State private var isClicked4 = false
    @State private var isClicked5 = false
    @State private var isClicked6 = false
    @State private var isClicked7 = false
    @State private var isClicked8 = false
    
    @State private var Kidsyes = "Yes"
    @State private var Kidsno = "no"
    @ObservedObject var myViewModel = DataViewModel()
    var body: some View {
        
        VStack{
            HStack{
                
                NavigationLink(destination:IntrestsSc2() , label: {
                    
                    
                    Image(systemName: "chevron.left")
                        .resizable()
                        .frame(width: 13,height: 20)
                        .foregroundColor(Color("Purble"))
                    Spacer()
                    
                    
                })
            }.padding(.leading)
                .navigationBarBackButtonHidden()
            
            Spacer()
            
            HStack{
                Text("Tell us more about ")
                    .fontWeight(.regular)
                
                    .font(Font.custom("SF Compact", size: 28))
                    .padding(.bottom)
                
                
                Text("yourself!")
                //  .foregroundColor(Color("Purple"))
                    .font(Font.custom("SF Compact", size: 35))
                    .foregroundColor(Color("Purble"))
                    .fontWeight(.bold)
                    .padding(.bottom)
                
            }
            
            
            ZStack(alignment: .leading) {
                Rectangle()
                    .frame(width: 327,height: 11)
                    .foregroundColor(Color(red: 0.851, green: 0.851, blue: 0.851))
                
                Rectangle()
                    .frame(width: 162.5,height: 11)
                    .foregroundColor(Color(red: 0.534, green: 0.294, blue: 0.638))
                
            }.padding(.bottom,50)
            //   Spacer()
            
                
                VStack(alignment: .leading,spacing:25){
                    Spacer()
                    if #available(iOS 16.0, *) {
                        Text("The number of people traveling with you?")
                            .frame(maxWidth: .infinity )
                            .fontWeight(.regular)
                            .multilineTextAlignment(.center)
                            .font(Font.custom("SF Compact", size: 25))
                            .padding(.bottom)
                    } else {
                        // Fallback on earlier versions
                    }
                    
                    VStack{
                        HStack{
                            
                            Button(action: {
                                myViewModel.selectedPeople = "1"
                                isClicked.toggle()
                            }) {
                                Text("1")
                                    .frame(width: 80,height: 10)
                                    .padding()
                                    .foregroundColor(isClicked ? Color(.white) : Color("Purble"))
                                
                            }.background(
                                Group {
                                    if isClicked {
                                        ZStack{
                                            
                                            
                                            //         Text("40")
                                            //            .foregroundColor(.white)
                                            
                                            RoundedRectangle(cornerRadius: 10)
                                            
                                                .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                            
                                            //                                 Text("40")
                                            //                                     .foregroundColor(.white)
                                        }
                                    }
                                }
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(purbleColor.ourPurble, lineWidth: 2)
                            )
                            .cornerRadius(10)
                            Button(action: {
                                myViewModel.selectedDays = "2"
                                isClicked1.toggle()
                            }) {
                                
                                Text("2")
                                    .frame(width: 80,height: 10)
                                
                                    .padding()
                                    .foregroundColor(isClicked1 ? Color(.white) : Color("Purble"))
                                
                            }.background(
                                Group {
                                    if isClicked1 {
                                        
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color("Purble"))
                                        
                                        
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                        
                                    }
                                }
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(purbleColor.ourPurble, lineWidth: 2)
                            )
                            .cornerRadius(10)
                            Button(action: {
                                myViewModel.selectedDays = "3"
                                isClicked2.toggle()
                            }) {
                                Text("3")
                                    .frame(width: 80,height: 10)
                                    .padding()
                                    .foregroundColor(isClicked2 ? Color(.white) : Color("Purble"))
                                
                            }.background(
                                Group {
                                    if isClicked2 {
                                        ZStack{
                                            
                                            
                                            //         Text("40")
                                            //            .foregroundColor(.white)
                                            
                                            RoundedRectangle(cornerRadius: 10)
                                            
                                                .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                            
                                            //                                 Text("40")
                                            //                                     .foregroundColor(.white)
                                        }
                                    }
                                }
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(purbleColor.ourPurble, lineWidth: 2)
                            )
                            .cornerRadius(10)
                            
                            
                        }
                        HStack{
                            
                            
                            
                            Button(action: {
                                myViewModel.selectedDays = "4"
                                isClicked3.toggle()
                            }) {
                                Text("4")
                                    .frame(width: 80,height: 10)
                                    .padding()
                                    .foregroundColor(isClicked3 ? Color(.white) : Color("Purble"))
                                
                            }.background(
                                Group {
                                    if isClicked3 {
                                        ZStack{
                                            
                                            
                                            //         Text("40")
                                            //            .foregroundColor(.white)
                                            
                                            RoundedRectangle(cornerRadius: 10)
                                            
                                                .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                            
                                            //                                 Text("40")
                                            //                                     .foregroundColor(.white)
                                        }
                                    }
                                }
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(purbleColor.ourPurble, lineWidth: 2)
                            )
                            .cornerRadius(10)
                            Button(action: {
                                myViewModel.selectedDays = "5"
                                isClicked4.toggle()
                            }) {
                                
                                Text("5")
                                    .frame(width: 80,height: 10)
                                
                                    .padding()
                                    .foregroundColor(isClicked4 ? Color(.white) : Color("Purble"))
                                
                            }.background(
                                Group {
                                    if isClicked4 {
                                        
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                        
                                    }
                                }
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(purbleColor.ourPurble, lineWidth: 2)
                            )
                            .cornerRadius(10)
                            Button(action: {
                                myViewModel.selectedDays = "6"
                                isClicked5.toggle()
                            }) {
                                Text("6")
                                    .frame(width: 80,height: 10)
                                    .padding()
                                    .foregroundColor(isClicked5 ? Color(.white) : Color("Purble"))
                                
                            }.background(
                                Group {
                                    if isClicked5 {
                                        ZStack{
                                            
                                            
                                            //         Text("40")
                                            //            .foregroundColor(.white)
                                            
                                            RoundedRectangle(cornerRadius: 10)
                                            
                                                .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                            
                                            //                                 Text("40")
                                            //                                     .foregroundColor(.white)
                                        }
                                    }
                                }
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(purbleColor.ourPurble, lineWidth: 2)
                            )
                            .cornerRadius(10)
                            
                        }
                        
                        
                        
                        
                    }.padding()
                    
                    if #available(iOS 16.0, *) {
                        Text("With kids?")
                            .frame(maxWidth: .infinity )
                            .fontWeight(.regular)
                            .multilineTextAlignment(.center)
                            .font(Font.custom("SF Compact", size: 25))
                            .padding(.bottom)
                    } else {
                        // Fallback on earlier versions
                    }
                    
                    
                    
                    HStack{
                        
                        
                        Spacer()
                        
                        
                        Button(action: {
                            isClicked8.toggle()
                        }) {
                            Text(Kidsno)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked8 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked8 {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                        
                                            .fill(/*@START_MENU_TOKEN@*/Color(red: 0.534, green: 0.294, blue: 0.638)/*@END_MENU_TOKEN@*/)
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Spacer()
                        Button(action: {
                            
                            isClicked7.toggle()
                        }) {
                            
                            Text(Kidsyes)
                                .frame(width: 80,height: 10)
                            
                                .padding()
                                .foregroundColor(isClicked7 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked7 {
                                    
                                    
                                    
                                    //         Text("40")
                                    //            .foregroundColor(.white)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(Color("Purble"))
                                    
                                    
                                    
                                    //                                 Text("40")
                                    //                                     .foregroundColor(.white)
                                    
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        
                        Spacer()
                        
                        
                    }.padding(.all)
                    Spacer()
                    
                    HStack{
                        Spacer()
                        NavigationLink(destination:interestsSc4() , label: {
                            ZStack{
                                Circle()
                                    .frame(width: 80,height: 79)
                                    .foregroundColor(purbleColor.ourPurble)
                                Image(systemName: "chevron.right")
                                    .resizable()
                                    .frame(width: 15,height: 20)
                                    .foregroundColor(.white)
                                
                                
                            }})
                    }.padding(.trailing).navigationBarBackButtonHidden()
                }
            }
            //
            //        .fullScreenCover(isPresented: $isClicked6) {
            //            IntrestsSc2()}
            
            
            
        }
        
        
        
        
        
        struct interstsSc3_Previews: PreviewProvider {
            static var previews: some View {
                interstsSc3()
            }
        }
        
//        var uniqueKey: String {
//            UUID().uuidString
//        }
    }


