//
//  DropdownSelector.swift
//  rahaf
//
//  Created by Rahaf Alhejaili on 26/08/1444 AH.
//


import SwiftUI

struct DropdownOption: Hashable {
    let key: String
    let value: String

    public static func == (lhs: DropdownOption, rhs: DropdownOption) -> Bool {
        return lhs.key == rhs.key
    }
}

struct DropdownRow: View {
    var option: DropdownOption
    var onOptionSelected: ((_ option: DropdownOption) -> Void)?
    
    var body: some View {
  
            Button(action: {
                if let onOptionSelected = self.onOptionSelected {
                    onOptionSelected(self.option)
                }
            }) {
                HStack {
                    Text(self.option.value)
                        .font(.system(size: 16))
                        .foregroundColor(Color("Purble"))
                    
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 5)
        
    }
}

struct Dropdown: View {
    var options: [DropdownOption]
    var onOptionSelected: ((_ option: DropdownOption) -> Void)?
    
    var body: some View {
 
            ScrollView {
                
                VStack(alignment: .leading, spacing: 1) {
                    
                    ForEach(self.options, id: \.self) { option in
                        DropdownRow(option: option, onOptionSelected: self.onOptionSelected)
                    }
                }
            }
            
            .frame(minHeight: CGFloat(options.count) * 50, maxHeight: 250)
            .padding(.vertical, 1)
            .background(Color.white)
            .overlay(RoundedRectangle(cornerRadius: 12)
                .stroke(Color("Purble"), lineWidth: 1))
        
    }
}

struct DropdownSelector: View {
    @State private var shouldShowDropdown = false
    @State private var selectedOption: DropdownOption? = nil
    var placeholder: String
    var options: [DropdownOption]
    var onOptionSelected: ((_ option: DropdownOption) -> Void)?
    private let buttonHeight: CGFloat = 24

    var body: some View {
        
        Button(action: {
            self.shouldShowDropdown.toggle()
            
        }) {
        
            HStack {
               
                    Text(selectedOption == nil ? placeholder : selectedOption!.value)
                        .font(.system(size: 14))
                        .foregroundColor(selectedOption == nil ? Color.purple: Color.purple)
                    
                    Spacer()
                    
                    
                    
                    DownIcon()
        }
            
       
}
        
        
        
        .padding(.horizontal)
        .cornerRadius(10)
        .frame(width: 350, height: 31)
        .overlay(RoundedRectangle(cornerRadius: 10)
        .stroke(Color("Purble"), lineWidth: 1))
        .overlay(
            VStack {
                if self.shouldShowDropdown {
                    Spacer(minLength: buttonHeight + 10)
                    Dropdown(options: self.options, onOptionSelected: { option in
                        shouldShowDropdown = false
                        selectedOption = option
                        self.onOptionSelected?(option)
                      
                    })
                    
                   
                }
            }, alignment: .topLeading
           
        )
        .background(
            RoundedRectangle(cornerRadius: 5).fill(Color.white)
        )
    }
}

struct DropdownSelector_Previews: PreviewProvider {
    @State private static var address: String = ""
    
    static var uniqueKey: String {
        UUID().uuidString
    }
    
    static let options: [DropdownOption] = [
        DropdownOption(key: uniqueKey, value: "16"),
        DropdownOption(key: uniqueKey, value: "17"),
        DropdownOption(key: uniqueKey, value: "29"),
        DropdownOption(key: uniqueKey, value: "30"),
        DropdownOption(key: uniqueKey, value: "31"),
        DropdownOption(key: uniqueKey, value: "32"),
        DropdownOption(key: uniqueKey, value: "33")
    ]
    
    
    static var previews: some View {
        
        VStack(spacing: 20) {
            DropdownSelector(
                placeholder: "Age",
                options: options,
                onOptionSelected: { option in
                    print(option)
                })
            .padding(.horizontal)
            .zIndex(1)
            .padding(.horizontal)
            
        }
    }
}

