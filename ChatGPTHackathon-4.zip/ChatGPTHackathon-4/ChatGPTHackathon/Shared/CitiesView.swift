//
//  CitiesView.swift
//  ChatGPTHackathon
//
//  Created by Maha Binmadhi on 17/03/2023.
//

import SwiftUI

class CityViewModel: ObservableObject {
    @Published var selectedCity: String = ""
    @Published var selectedInterests: String = ""
    @Published var selectedPurpose: String = ""
    @Published var selectedPeople: String = ""
    @Published var hasKids: String = ""
    @Published var selectedDays: String = ""
    @Published var selectedBudget: String = ""
}

struct CitiesView: View {
    @ObservedObject var myViewModel = CityViewModel()
  //  @ObservedObject var vm: ViewModel
    
    @State private var Jeddah = NSLocalizedString("Jeddah", comment: "")
    @State private var Riyadh = NSLocalizedString("Riyadh", comment: "")
    @State private var Tabuk =  NSLocalizedString("Tabuk", comment: "")
    @State var isSelected = false
    @State var City: String = ""
    
    @State var isshown : Bool = false
    var body: some View {
        
        NavigationView{
            VStack {
                if #available(iOS 16.0, *) {
                    Text("Where are you want to go?")
                        .frame(maxWidth: .infinity ,alignment: .leading)
                        .font(Font.custom("SF Pro", size: 25))
                        .padding()
                        .padding()
                        .bold()
                } else {
                    // Fallback on earlier versions
                }
                
                ScrollView{
                    VStack{
                        Button(action:{
                            // isshown.toggle()
                            isshown.toggle()
                            City = "Riyadh"
                            myViewModel.selectedCity = "Riyadh"
//                            print(myViewModel.selectedCity)
                            
                        }){
                            
                            ZStack(alignment:.top){
                                Image("Image 2")
                                    .resizable()
                                    .frame(maxWidth: .infinity ,alignment: .center)
                                    .frame(width: 350, height: 200)
                                    .cornerRadius(5)
                                Text(Riyadh)
                                    .bold()
                                    .foregroundColor(.white)
                                    .padding(.top, 90)
                                    .font(Font.custom("SF Pro", size: 30))
                                
                            } // vs close
                            // zst closer
                            //nav link
                        }//c foreach
                        
                        Button(action:{
                            // isshown.toggle()
                            isshown.toggle()
                            City = "Jeddah"
                            myViewModel.selectedCity = "Jeddah"
                            
                        }){
                            ZStack(alignment:.top){
                                Image("Image")
                                    .resizable()
                                    .frame(maxWidth: .infinity ,alignment: .center)
                                    .frame(width: 350, height: 200)
                                    .cornerRadius(5)
                                Text(Jeddah)
                                    .bold()
                                    .foregroundColor(.white)
                                    .padding(.top, 90)
                                    .font(Font.custom("SF Pro", size: 30))
                                
                            }
                        }// vs close
                        
                        Button(action:{
                            // isshown.toggle()
                            isshown.toggle()
                            City = "Tabuk"
                            myViewModel.selectedCity = "Tabuk"
                         //   print(myViewModel)
                          //  print(myViewModel.selectedCity)
                        }){
                            ZStack(alignment:.top){
                                Image("Image 1")
                                    .resizable()
                                    .frame(maxWidth: .infinity ,alignment: .center)
                                    .frame(width: 350, height: 200)
                                    .cornerRadius(5)
                                Text(Tabuk)
                                    .bold()
                                    .foregroundColor(.white)
                                    .padding(.top, 90)
                                    .font(Font.custom("SF Pro", size: 30))
                                
                            }
                            // zst closer
                            //nav link
                        }//c foreach
                        
                        
                    }
                }//close scroll
            }//vs close
        }//nav
        .fullScreenCover(isPresented: $isshown){
            
            IntrestsSc2()
        }.navigationBarBackButtonHidden()
    }
    
    
    struct CitiesView_Previews: PreviewProvider {
        static var previews: some View {
            CitiesView(myViewModel: CityViewModel())
        }
    }
}
