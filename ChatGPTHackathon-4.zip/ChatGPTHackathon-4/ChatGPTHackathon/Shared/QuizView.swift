//
//  QuizView.swift
//  ChatGPTHackathon
//
//  Created by Maha Binmadhi on 17/03/2023.
//


import AVKit
import SwiftUI

struct QuizView: View {
    @ObservedObject var vm: ViewModel
    @State var messages: [String] = []
    @State var intrest1 = ""
    @State var intrest2 = ""
    @State var intrest3 = ""
   
 @ObservedObject var myViewModel = DataViewModel()

struct purbleColor{
static let ourPurble = Color("Purble")

    }

//    @State var City: String
    @State private var isClicked = false
    @State private var isClicked1 = false
    @State private var isClicked2 = false
    @State private var isClicked3 = false
    @State private var isClicked4 = false
    @State private var isClicked5 = false
    @State private var isClicked6 = false
    @State private var nature = "Nature"
    @State private var Art = "Art"
    @State private var Music = "Music"
    @State private var Sport = "Sport"
    @State private var Shopping  = "Shopping"
    @State private var adventure = "adventure"
    @State var selectedCity = ""
    @State var selectedInterests: String = ""
    @State var selectedPurpose: String = ""
    @State var selectedPeople: String = ""
    @State var selectedDays: String = ""
    @State var selectedBudget: String = ""
    @State var shownll : Bool = false
//    private var Intersst = "Nature"
//    private var Intersst1 = "Art"
//    private var Intersst2 = "Music"
//   private var Intersst3 = "ll"


//    var interst1=interest(usernamea: NSLocalizedString("Jeddah", comment: ""))
//    var interest2=interest(usernamea:NSLocalizedString("Riyadh",comment: ""))
//    var interest3=interest(usernamea: NSLocalizedString("Tabuk",comment: ""))

    var body: some View {
        NavigationView{
            VStack{
                
                
//                ScrollView {
//                    LazyVStack(spacing: 0) {
//                        ForEach(vm.messages) { message in
//                            MessageRowView(message: message) { message in
//                                Task { @MainActor in
//                                    await vm.retry(message: message)
//                                }
//                            }
//                        }
//                    }
//                    .onTapGesture {
//
//                    }
//                }
//
                Spacer()
                Text("Tell us more about yourself!")
                    .fontWeight(.regular)
                
                    .font(Font.custom("SF Compact", size: 30))
                    .padding(.bottom)
                
                ZStack(alignment: .leading) {
                    Rectangle()
                        .frame(width: 327,height: 11)
                        .foregroundColor(Color(red: 0.851, green: 0.851, blue: 0.851))
                    
                    //               Rectangle()
                    //                    .frame(width: 70,height: 11)
                    //                 .foregroundColor(/@START_MENU_TOKEN@/Color(red: 0.534, green: 0.294, blue: 0.638)/@END_MENU_TOKEN@/)
                    
                }
                
                Spacer()
                Text("What are you interested in?")
                    .fontWeight(.regular)
                
                    .font(Font.custom("SF Compact", size: 25))
                    .padding(.bottom)
                
                VStack{
                    HStack{
                        
                        
                        
                        Button(action: {
                            
                            Task { @MainActor in
                                //                        vm.inputMessage = "Places for nature in Saudi Arabia"
                                //                            messages.append(vm.inputMessage)
                                if intrest1 == "" {
                                    intrest1 = "nature"
                                }else if intrest2 == "" {
                                    intrest2 = "nature"
                                }else {
                                    intrest3 = "nature"
                                }
                                
                            }
                            isClicked.toggle()
                        }) {
                            Text(nature)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            Task { @MainActor in
                                //                        vm.inputMessage = "Places for art in Saudi Arabia"
                                //                            messages.append(vm.inputMessage)
                                
                                if intrest1 == "" {
                                    intrest1 = "Art"
                                }else if intrest2 == "" {
                                    intrest2 = "Art"
                                }else {
                                    intrest3 = "Art"
                                }
                                
                            }
                            isClicked1.toggle()
                        }) {
                            
                            Text(Art)
                                .frame(width: 80,height: 10)
                            
                                .padding()
                                .foregroundColor(isClicked1 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked1 {
                                    
                                    
                                    
                                    //         Text("40")
                                    //            .foregroundColor(.white)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(Color("Purble"))
                                    
                                    
                                    
                                    //                                 Text("40")
                                    //                                     .foregroundColor(.white)
                                    
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            Task { @MainActor in
                                //                        vm.inputMessage = "Places for music in Saudi Arabia"
                                //                            messages.append(vm.inputMessage)
                                
                                if intrest1 == "" {
                                    intrest1 = "Music"
                                }else if intrest2 == "" {
                                    intrest2 = "Music"
                                }else {
                                    intrest3 = "Music"
                                }
                                
                            }
                            isClicked2.toggle()
                        }) {
                            Text(Music)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked2 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked2 {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        
                        
                    }
                    HStack{
                        
                        
                        
                        Button(action: {
                            Task { @MainActor in
                                //                        vm.inputMessage = "Places for adventure in Saudi Arabia"
                                //                            messages.append(vm.inputMessage)
                                if intrest1 == "" {
                                    intrest1 = "adventure"
                                }else if intrest2 == "" {
                                    intrest2 = "adventure"
                                }else {
                                    intrest3 = "adventure"
                                }
                            }
                            isClicked3.toggle()
                        }) {
                            Text(adventure)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked3 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked3 {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            Task { @MainActor in
                                //                        vm.inputMessage = "Places for sport in Saudi Arabia"
                                //                            messages.append(vm.inputMessage)
                                if intrest1 == "" {
                                    intrest1 = "Sport"
                                }else if intrest2 == "" {
                                    intrest2 = "Sport"
                                }else {
                                    intrest3 = "Sport"
                                }
                            }
                            isClicked4.toggle()
                        }) {
                            
                            Text(Sport)
                                .frame(width: 80,height: 10)
                            
                                .padding()
                                .foregroundColor(isClicked4 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked4 {
                                    
                                    
                                    
                                    //         Text("40")
                                    //            .foregroundColor(.white)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                    
                                    
                                    
                                    //                                 Text("40")
                                    //                                     .foregroundColor(.white)
                                    
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            Task { @MainActor in
                                
                                //                            vm.inputMessage = "Places for shopping in Saudi Arabia"
                                //                            messages.append(vm.inputMessage)
                                if intrest1 == "" {
                                    intrest1 = "Shopping"
                                }else if intrest2 == "" {
                                    intrest2 = "Shopping"
                                }else {
                                    intrest3 = "Shopping"
                                }
                            }
                            isClicked5.toggle()
                        }) {
                            Text(Shopping)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked5 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked5 {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        
                        
                    }
                }
                Spacer()
                HStack{
                    Spacer()
                    NavigationLink(destination: testre(vm: vm)) {
                        Button (action:{
                            Task { @MainActor in
                              //  vm.inputMessage = "If I like \(intrest1), \(intrest2),\(intrest3) what places should I visit in \(selectedCity)?"
                                
                                
                                vm.inputMessage = "suggest some upcoming {\(intrest1), \(intrest2),\(intrest3)} events in the city of {\("Riyadh")} in Saudi Arabia with possible dates For \("2") for \("4") days. The Budget should be {\("5,000SAR - 8,000SAR")}You can also check the provided info at https://calendar.visitsaudi.com/en/eventsThe needed details in order are Day, Date, Location, Event Name, location & Budget. Recommend one to two events per day on each consecutive day."
                                
                               
                                
                                await vm.sendTapped()
                                shownll.toggle()
                            }
                            isClicked6.toggle()
                            print(messages)
                            print(vm.sendTapped)
                            print(selectedCity)
                            print("test",vm.inputMessage)
                            print(vm.sendTapped)
                            
                            
                            
                        }){
                            ZStack{
                                Circle()
                                    .frame(width: 80,height: 79)
                                    .foregroundColor(purbleColor.ourPurble)
                                Image(systemName: "chevron.right")
                                    .frame(width: 90,height: 80)
                                    .foregroundColor(.white)
                                
                                
                            }}}
                }.padding(.trailing)
                
            }
        }
        .fullScreenCover(isPresented:$shownll){
            testre(vm: vm)
        }





    }
}

struct intrests_Previews: PreviewProvider {
    static var previews: some View {
        QuizView(vm: ViewModel(api: ChatGPTAPI(apiKey: "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")))
    }
}
