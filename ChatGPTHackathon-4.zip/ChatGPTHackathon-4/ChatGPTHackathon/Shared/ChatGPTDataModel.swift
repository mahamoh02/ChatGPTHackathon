//
//  ChatGPTDataModel.swift
//  ChatGPTHackathon
//
//  Created by Maha Binmadhi on 17/03/2023.
//

import Foundation



struct Prompt: Codable {
let upcominigEvents: [Event]
}

// MARK: - Event
struct Event: Codable {
let day, date, location, event: String
let budget: String

enum CodingKeys: String, CodingKey {
    case day, date, location, event
//    case eventName = "event_name"
    case budget
}
    
}



