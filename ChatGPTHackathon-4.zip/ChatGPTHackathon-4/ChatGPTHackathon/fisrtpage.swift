import SwiftUI


class DataViewModel: ObservableObject {
    @Published var selectedCity: String = ""
    @Published var selectedInterests: String = ""
    @Published var selectedPurpose: String = ""
    @Published var selectedPeople: String = ""
    @Published var hasKids: String = ""
    @Published var selectedDays: String = ""
    @Published var selectedBudget: String = ""
}

struct fisrtpage: View {
    
    @State var isshownhome=false
    @ObservedObject var myViewModel = DataViewModel()
    var body: some View {
        
        NavigationView{
            ZStack{
                Image("background")
                    .resizable()
                    .ignoresSafeArea()
                VStack{
                    Text("You do not have any trip registered")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .font(.system(size: 30))
                        .multilineTextAlignment(.center)
                        .padding(8)
                    
                    Text("start planing !")
                        .foregroundColor(.white)
                        .font(.system(size: 20))
                    
                    
                }
                .padding(.bottom ,70)
                
//                Button {
//                    isshownhome.toggle()
//
//                } label:{
//                    ZStack{
//                        Circle()
//                            .frame(width:80  , height: 80)
//                            .foregroundColor(Color ("Purble"))
//                            .shadow(radius: 10)
//                        Image(systemName: "airplane")
//                            .resizable()
//                            .frame(width:30  , height: 30)
//                            .foregroundColor(.white)
//
//
//                    }.padding(.top,650)
//                        .padding(.leading,260)
                
                VStack{
                    Spacer()
                    HStack{
                        Spacer()
                        NavigationLink(destination:CitiesView() , label: {
                            ZStack{
                                Circle()
                                    .frame(width: 80,height: 79)
                                    .foregroundColor(Color("Purble"))
                                Image(systemName: "airplane")
                                    .resizable()
                                    .frame(width: 30,height: 30)
                                    .foregroundColor(.white)
                                
                                
                            }})
                    }.padding(.trailing)
                        .padding(.bottom)
                        .navigationBarBackButtonHidden()
                }
            }
        }
        }
        }
    


struct fisrtpage_Previews: PreviewProvider {
    static var previews: some View {
        fisrtpage()
    }
}
