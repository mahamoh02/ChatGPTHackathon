import SwiftUI

struct IntrestsSc2: View {
    struct purbleColor{
        
        static let ourPurble = Color("Purble")
        
        
    }
    @State private var isClicked = false
    @State private var isClicked1 = false
    @State private var isClicked2 = false
    @State private var isClicked3 = false
    @State private var isClicked4 = false
    @State private var isClicked5 = false
    @State private var isClicked6 = false
    @State private var Work = NSLocalizedString("Work", comment: "")
    @State private var Relaxion = NSLocalizedString("Relaxion", comment: "")
    @State private var Treatment = NSLocalizedString("Treatment", comment: "")
    @State private var EXploringTheCulture = NSLocalizedString("Exploring", comment: "")
    @State private var Events  = NSLocalizedString("Events", comment: "Sport")
    @State private var Newadventure = NSLocalizedString("Adventure", comment: "")
    @ObservedObject var myViewModel = DataViewModel()
    var body: some View {
        NavigationView{
            VStack{
                HStack{
                    NavigationLink(destination:CitiesView() , label: {
                        
                        
                        Image(systemName: "chevron.left")
                            .resizable()
                            .frame(width: 13,height: 20)
                            .foregroundColor(Color("Purble"))
                        Spacer()
                        
                        
                    })
                }.padding(.leading)
                    .navigationBarBackButtonHidden()
                
                Spacer()
                
                HStack{
                    Text("Tell us more about ")
                        .fontWeight(.regular)
                    
                        .font(Font.custom("SF Compact", size: 28))
                        .padding(.bottom)
                    
                    
                    Text("yourself!")
                    //  .foregroundColor(Color("Purple"))
                        .font(Font.custom("SF Compact", size: 35))
                        .foregroundColor(Color("Purble"))
                        .fontWeight(.bold)
                        .padding(.bottom)
                    
                }
                
                ZStack(alignment: .leading) {
                    Rectangle()
                        .frame(width: 327,height: 11)
                        .foregroundColor(Color(red: 0.851, green: 0.851, blue: 0.851))
                    
                    Rectangle()
                        .frame(width: 81.25,height: 11)
                        .foregroundColor(Color(red: 0.534, green: 0.294, blue: 0.638))
                    
                }
                Spacer()
                Text("What's the purpose of the trip?")
                    .fontWeight(.regular)
                
                    .font(Font.custom("SF Compact", size: 25))
                    .padding(.bottom)
                
                VStack{
                    HStack{
                        
                        Button(action: {
                            myViewModel.selectedPurpose = "Work"
                            isClicked.toggle()
                        }) {
                            Text(Work)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                        
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            myViewModel.selectedPurpose = "Relaxion"
                            isClicked1.toggle()
                        }) {
                            
                            Text(Relaxion)
                                .frame(width: 80,height: 10)
                            
                                .padding()
                                .foregroundColor(isClicked1 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked1 {
                                    
                                    
                                    
                                    //         Text("40")
                                    //            .foregroundColor(.white)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(Color("Purble"))
                                    
                                    
                                    
                                    //                                 Text("40")
                                    //                                     .foregroundColor(.white)
                                    
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            myViewModel.selectedPurpose = "EXploring"
                            isClicked2.toggle()
                        }) {
                            Text(EXploringTheCulture)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked2 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked2 {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                        
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        
                        
                    }
                    HStack{
                        
                        
                        
                        Button(action: {
                            myViewModel.selectedPurpose = "adventure"
                            isClicked3.toggle()
                        }) {
                            Text(Newadventure)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked3 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked3 {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                        
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            myViewModel.selectedPurpose = "Treatment"
                            isClicked4.toggle()
                        }) {
                            
                            Text(Treatment)
                                .frame(width: 80,height: 10)
                            
                                .padding()
                                .foregroundColor(isClicked4 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked4 {
                                    
                                    
                                    
                                    //         Text("40")
                                    //            .foregroundColor(.white)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                    
                                    
                                    
                                    //                                 Text("40")
                                    //                                     .foregroundColor(.white)
                                    
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        Button(action: {
                            myViewModel.selectedPurpose = "Events"
                            isClicked5.toggle()
                        }) {
                            Text(Events)
                                .frame(width: 80,height: 10)
                                .padding()
                                .foregroundColor(isClicked5 ? Color(.white) : Color("Purble"))
                            
                        }.background(
                            Group {
                                if isClicked5 {
                                    ZStack{
                                        
                                        
                                        //         Text("40")
                                        //            .foregroundColor(.white)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                        
                                            .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                        
                                        //                                 Text("40")
                                        //                                     .foregroundColor(.white)
                                    }
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(purbleColor.ourPurble, lineWidth: 2)
                        )
                        .cornerRadius(10)
                        
                        
                    }
                }
                Spacer()
                HStack{
                    Spacer()
                    NavigationLink(destination: interstsSc3() , label: {
                        ZStack(alignment: .center){
                            Circle()
                                .frame(width: 80,height: 79)
                                .foregroundColor(purbleColor.ourPurble)
                            Image(systemName: "chevron.right")
                                .resizable()
                                .frame(width: 15,height: 20)
                                .foregroundColor(.white)
                            
                            
                            
                        }})
                }.padding(.trailing)
                    .navigationBarBackButtonHidden()
            }.tint(Color("Purble"))
        }.navigationBarBackButtonHidden()
    }






    }


struct IntrestsSc2_Previews: PreviewProvider {
    static var previews: some View {
        IntrestsSc2()
    }
}
