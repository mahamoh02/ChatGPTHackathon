//
//  XCAChatGPTApp.swift
//  ChatGPTHackathon
//
//  Created by Moamen on 14/03/2023.
//

import SwiftUI

@main
struct ChatGPTHackathonApp: App {
    
    @StateObject var vm = ViewModel(api: ChatGPTAPI(apiKey: "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"))
    
    
    var body: some Scene {
        WindowGroup {
            if #available(iOS 16.0, *) {
                NavigationStack {
                //   QuizView(vm: vm)
                    fisrtpage()
                 //   ContentView(vm: vm)
                        .toolbar {
                            ToolbarItem {
                                Button("Clear") { vm.clearMessages() }
                                    .disabled(vm.isInteractingWithChatGPT)
                            }
                        }
                }
            } else {
                // Fallback on earlier versions
            }
        }
    }
}
