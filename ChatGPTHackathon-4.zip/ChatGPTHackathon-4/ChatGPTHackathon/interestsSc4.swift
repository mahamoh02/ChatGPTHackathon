//
//  interestsSc4.swift
//  rahaf
//
//  Created by Rahaf Alhejaili on 25/08/1444 AH.
//

import SwiftUI

struct interestsSc4: View {
    struct purbleColor{
        
        static let ourPurble = Color("Purble")
        
        
    }
    
    @State private var isClicked = false
    @State private var isClicked1 = false
    @State private var isClicked2 = false
    @State private var isClicked3 = false
    @State private var isClicked4 = false
    @State private var isClicked5 = false
    @State private var isClicked6 = false
    @State private var isClicked7 = false
    @State private var isClicked8 = false
    
    @ObservedObject var myViewModel = DataViewModel()

    var body: some View {
        VStack{
            HStack{
                
                NavigationLink(destination: interstsSc3() , label: {
                    
                    
                    Image(systemName: "chevron.left")
                        .resizable()
                        .frame(width: 13,height: 20)
                        .foregroundColor(Color("Purble"))
                    Spacer()
                    
                    
                })
            }.padding(.leading)
                .navigationBarBackButtonHidden()
            
            
            HStack{
                Text("Tell us more about ")
                    .fontWeight(.regular)
                
                    .font(Font.custom("SF Compact", size: 28))
                    .padding(.bottom)
                
                
                Text("yourself!")
                //  .foregroundColor(Color("Purple"))
                    .font(Font.custom("SF Compact", size: 35))
                    .foregroundColor(Color("Purble"))
                    .fontWeight(.bold)
                    .padding(.bottom)
                
            }
            ZStack(alignment: .leading) {
                Rectangle()
                    .frame(width: 327,height: 11)
                    .foregroundColor(Color(red: 0.851, green: 0.851, blue: 0.851))
                
                Rectangle()
                    .frame(width: 243.75,height: 11)
                    .foregroundColor(Color(red: 0.534, green: 0.294, blue: 0.638))
                
            }.padding(.bottom , 50)
            
            
            
            if #available(iOS 16.0, *) {
                Text("For how long ?")
                    .frame(maxWidth: .infinity )
                    .fontWeight(.regular)
                    .multilineTextAlignment(.center)
                    .font(Font.custom("SF Compact", size: 25))
                    .padding(.bottom)
            } else {
                // Fallback on earlier versions
            }
            HStack{
                
                Button(action: {
                    myViewModel.selectedDays = "1"
                    isClicked.toggle()
                }) {
                    Text("1")
                        .frame(width: 80,height: 10)
                        .padding()
                        .foregroundColor(isClicked ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked {
                            ZStack{
                                
                                
                                //         Text("40")
                                //            .foregroundColor(.white)
                                
                                RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                
                                //                                 Text("40")
                                //                                     .foregroundColor(.white)
                            }
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                Button(action: {
                    myViewModel.selectedDays = "2"
                    isClicked1.toggle()
                }) {
                    
                    Text("2")
                        .frame(width: 80,height: 10).padding()
                        .foregroundColor(isClicked1 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked1 {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color("Purble"))
                            
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                Button(action: {
                    myViewModel.selectedDays = "3"
                    isClicked2.toggle()
                }) {
                    Text("3")
                        .frame(width: 80,height: 10)
                        .padding()
                        .foregroundColor(isClicked2 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked2 {
                            ZStack{
                                
                                
                                //         Text("40")
                                //            .foregroundColor(.white)
                                
                                RoundedRectangle(cornerRadius: 10)
                                
                                    .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                
                                //                                 Text("40")
                                //                                     .foregroundColor(.white)
                            }
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                
                
            }
            HStack{
                
                
                
                Button(action: {
                    myViewModel.selectedDays = "4"
                    isClicked3.toggle()
                }) {
                    Text("4")
                        .frame(width: 80,height: 10)
                        .padding()
                        .foregroundColor(isClicked3 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked3 {
                            ZStack{
                                
                                
                                //         Text("40")
                                //            .foregroundColor(.white)
                                
                                RoundedRectangle(cornerRadius: 10)
                                
                                    .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                
                                //                                 Text("40")
                                //                                     .foregroundColor(.white)
                            }
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                Button(action: {
                    myViewModel.selectedDays = "5"
                    isClicked4.toggle()
                }) {
                    
                    Text("5")
                        .frame(width: 80,height: 10)
                    
                        .padding()
                        .foregroundColor(isClicked4 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked4 {
                            
                            
                            
                            //         Text("40")
                            //            .foregroundColor(.white)
                            
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                            
                            
                            
                            //                                 Text("40")
                            //                                     .foregroundColor(.white)
                            
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                Button(action: {
                    myViewModel.selectedDays = "6"
                    isClicked5.toggle()
                }) {
                    Text("6")
                        .frame(width: 80,height: 10)
                        .padding()
                        .foregroundColor(isClicked5 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked5 {
                            ZStack{
                                
                                
                                //         Text("40")
                                //            .foregroundColor(.white)
                                
                                RoundedRectangle(cornerRadius: 10)
                                
                                    .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                
                                //                                 Text("40")
                                //                                     .foregroundColor(.white)
                            }
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                
            }
        Spacer()
            if #available(iOS 16.0, *) {
                Text("On budget?")
                    .frame(maxWidth: .infinity )
                    .fontWeight(.regular)
                    .multilineTextAlignment(.center)
                    .font(Font.custom("SF Compact", size: 25))
                
            } else {
                // Fallback on earlier versions
            }
            
            VStack{
                
                
                
                Button(action: {
                    myViewModel.selectedBudget = "1,000SAR - 3,000SAR"
                    isClicked6.toggle()
                }) {
                    Text("1000SAR - 3000SAR")
                        .frame(width: 200,height: 10)
                        .padding()
                        .foregroundColor(isClicked6 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked6 {
                            ZStack{
                                
                                
                                //         Text("40")
                                //            .foregroundColor(.white)
                                
                                RoundedRectangle(cornerRadius: 10)
                                
                                    .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                                
                                //                                 Text("40")
                                //                                     .foregroundColor(.white)
                            }
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                Button(action: {
                    myViewModel.selectedBudget = "3,000SAR - 5,000SAR"
                    isClicked7.toggle()
                }) {
                    
                    Text("3,000SAR - 5,000SAR")
                        .frame(width:200,height: 10)
                    
                        .padding()
                        .foregroundColor(isClicked4 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked7 {
                            
                            
                            
                            //         Text("40")
                            //            .foregroundColor(.white)
                            
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                            
                            
                            
                            //                                 Text("40")
                            //                                     .foregroundColor(.white)
                            
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                
                Button(action: {
                    myViewModel.selectedBudget = "5,000SAR - 8,000SAR"
                    isClicked8.toggle()
                }) {
                    
                    Text("5,000SAR - 8,000SAR")
                        .frame(width:200,height: 10)
                    
                        .padding()
                        .foregroundColor(isClicked4 ? Color(.white) : Color("Purble"))
                    
                }.background(
                    Group {
                        if isClicked8 {
                            
                            
                            
                            //         Text("40")
                            //            .foregroundColor(.white)
                            
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color(red: 0.534, green: 0.294, blue: 0.638))
                            
                            
                            
                            //                                 Text("40")
                            //                                     .foregroundColor(.white)
                            
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(purbleColor.ourPurble, lineWidth: 2)
                )
                .cornerRadius(10)
                
            }.padding()
            
//            Spacer()
            
            HStack(alignment: .bottom){
                Spacer()
                NavigationLink(destination: QuizView(vm: ViewModel(api: ChatGPTAPI(apiKey: "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"))) , label: {
                    ZStack{
                        Circle()
                            .frame(width: 80,height: 79)
                            .foregroundColor(purbleColor.ourPurble)
                        Image(systemName: "chevron.right")
                            .resizable()
                            .frame(width: 15,height: 20)
                            .foregroundColor(.white)
                        
                        
                    }
                    
                }
                ).padding(.trailing).navigationBarBackButtonHidden()
            }
        }
    }
    
    
    //
    //        .fullScreenCover(isPresented: $isClicked6) {
    //            IntrestsSc2()}
    
    
    
    
    
    
    
    struct interestsSc4_Previews: PreviewProvider {
        static var previews: some View {
            interestsSc4()
        }
    }
}



