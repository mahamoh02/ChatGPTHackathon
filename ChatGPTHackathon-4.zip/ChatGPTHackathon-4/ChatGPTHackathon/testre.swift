//
//  testre.swift
//  ChatGPTHackathon
//
//  Created by Haneen Behery on 26/08/1444 AH.
//

import SwiftUI

struct testre: View {
    
    @ObservedObject var vm: ViewModel
    
    var body: some View {
        ScrollView {
        LazyVStack(spacing: 0) {
        ForEach(vm.messages) { message in
        MessageRowView(message: message) { message in
        Task { @MainActor in
        await vm.retry(message: message)
        }
        }
        }
        }
        .onTapGesture {
        
        }
        }

    }
}

struct testre_Previews: PreviewProvider {
    static var previews: some View {
      //  testre()
        testre(vm: ViewModel(api: ChatGPTAPI(apiKey: "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")))
    }
}
