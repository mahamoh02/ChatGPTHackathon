//
//  DownIcon.swift
//  rahaf
//
//  Created by Rahaf Alhejaili on 26/08/1444 AH.
//
import SwiftUI

struct DownIcon: View {
    

    var body: some View {
        Image(systemName: "chevron.down")
            .frame(width: 20,height: 20)
            .foregroundColor(Color("Purble"))
            
    }
    }



struct DownIcon_Previews: PreviewProvider {
    static var previews: some View {
        DownIcon()
    }
}
